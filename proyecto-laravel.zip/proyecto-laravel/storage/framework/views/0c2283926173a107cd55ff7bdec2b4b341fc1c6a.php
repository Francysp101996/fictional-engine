<?php if(Auth::user()->image): ?>
    <div class="container-avatar">
        <img src="<?php echo e(route('user.avatar', ['filename'=>Auth::user()->image])); ?>" alt="" class="avatar">
        <!-- <img src="<?php echo e(url('/user/avatar/'.Auth::user()->image)); ?>" alt=""> -->
    </div>
<?php endif; ?>